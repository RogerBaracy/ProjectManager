export const artigo3 = {
    titulo:"titulo3",
    conteudo:"Nullam volutpat risus nec leo commodo, ut interdum diam laoreet. Sed non consequat odio. Nec orci ornare consequat. Praesent lacinia ultrices consectetur. Sed non ipsum felis. Atirei o pau no gatis, per gatis num morreus. Diuretics paradis num copo é motivis de denguis. "
}