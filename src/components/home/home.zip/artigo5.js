export const artigo5 = {
    titulo:"titulo5",
    conteudo:"Não sou faixa preta cumpadi, sou preto inteiris, inteiris. Sapien in monti palavris qui num significa nadis i pareci latim. Si num tem leite então bota uma pinga aí cumpadi! Aenean aliquam molestie leo, vitae iaculis nisl"
}