import artigo1 from "./artigo1"
import artigo2 from "./artigo2"
import artigo3 from "./artigo3"
import artigo4 from "./artigo4"
import artigo5 from "./artigo5"
export default artigos = [
    {
        artigo: artigo1
    },
    {
        artigo: artigo2
    },
    {
        artigo: artigo3
    },
    {
        artigo: artigo4
    },
    {
        artigo: artigo5
    },
]