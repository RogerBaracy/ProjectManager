export const artigo4 = {
    titulo:"titulo4",
    conteudo:"Paisis, filhis, espiritis santis. In elementis mé pra quem é amistosis quis leo. Quem num gosta di mé, boa gentis num é. Pra lá , depois divoltis porris, paradis"
}